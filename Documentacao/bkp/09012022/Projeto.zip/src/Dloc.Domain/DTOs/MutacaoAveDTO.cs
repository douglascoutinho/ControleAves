﻿namespace Dloc.Domain.DTOs
{
    public class MutacaoAveDTO
    {
        public int id_mutacaoAve { get; set; }
        public int id_mutacao { get; set; }
        public string ds_mutacao { get; set; }
    }
}
