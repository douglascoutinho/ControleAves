﻿namespace Dloc.Domain.DTOs
{
    public class PortadorAveDTO
    {
        public int id_portadorAve { get; set; }
        public int id_portador { get; set; }
        public string ds_portador { get; set; }
    }
}
