﻿namespace Dloc.Domain.Enumeration
{
    public enum ParenteEnun
    {
        Pai,
        Mae,
        Filho
    }
}