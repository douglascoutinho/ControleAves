﻿namespace Dloc.Domain.Enumeration
{
    public enum AcaoEnun
    {
        Cadastrar,
        Editar,
        Excluir
    }
}