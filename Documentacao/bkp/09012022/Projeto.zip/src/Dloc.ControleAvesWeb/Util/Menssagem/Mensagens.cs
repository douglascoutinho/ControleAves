﻿namespace DLOC.ControleAvesWeb.Util.Menssagem
{
    public static class Mensagens
    {
        public static string msgCadastroSucesso = "Cadastro Realizado com Sucesso!";
        public static string msgAlteracaoSucesso = "Alteração Realizada com Sucesso!";
        public static string msgExclusaoSucesso = "Exclusão Realizada com Sucesso!";
        public static string msgDesativarSucesso = "Desativado com Sucesso!";
        public static string msgReativarSucesso = "Reativado com Sucesso!";
        public static string msgCampoObrigatorio = "Campo Obrigatorio!";
        public static string msgErro = "Ocorreu um erro inesperado, favor entrar em contato com administrador do sistema!";
    }
}
