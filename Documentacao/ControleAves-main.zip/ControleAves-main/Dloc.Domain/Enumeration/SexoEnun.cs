﻿namespace Dloc.Domain.Enumeration
{
    public enum SexoEnun
    {
        Femea = 0,
        Macho,
        Ambos
    }
}