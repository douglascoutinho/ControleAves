﻿using Dloc.Domain.DTOs;
using Dloc.Domain.Entities;
using System.Collections.Generic;

namespace Dloc.Domain.IRepositories
{
    public interface IAveRepository
    {
        Ave GetById(int id);
        List<Ave> GetAll();
        void Register(Ave ave);
        void Update(Ave ave);
        string GetCodigo();

        Pai GetPai(int id);
        Mae GetMae(int id);
        Filho GetFilho(int id);
        List<Filho> GetFilhos(int id);
        List<Filho> GetNetos(List<Filho> filhos);
        List<Filho> GetBisnetos(List<Filho> netos);
        List<FilhoDTO> GetTrinetos(List<Filho> bisnetos);

        List<Casamento> GetCasamentos(int id);
        void ExcluirPortador(int id);
        void ExcluirMutacao(int id);

        bool Existe(int id, int parente);

        IDictionary<int, string> GetDropMutacoes();
        IDictionary<int, string> GetDropPortadores();
        IDictionary<int, string> GetDropAves(int sexo);
        IDictionary<int, string> GetDropFilhos();
        void ExcluirFilho(int id);
    }
}
