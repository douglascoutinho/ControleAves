﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Dloc.Data.Context;
using Dloc.Domain.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Dloc.ControleAvesWeb.Controllers
{
    public class PortadorController : Controller
    {
        private readonly DataContext _context;

        public PortadorController(DataContext context) => _context = context;

        public ActionResult Index() => View(_context.Portador.ToList());

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Portador model)
        {
            try
            {
                _context.Entry(model).State = EntityState.Added;
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));

            }
            catch(Exception e)
            {
                return View();
            }
        }

        public ActionResult Edit(int id) => View(_context.Portador.Find(id));

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Portador model)
        {
            try
            {
                _context.Entry(model).State = EntityState.Modified;
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));

            }
            catch
            {
                return View();
            }
        }

        public ActionResult Delete(int id)
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
