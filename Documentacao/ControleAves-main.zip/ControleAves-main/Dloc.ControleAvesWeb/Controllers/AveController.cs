﻿using Dloc.ControleAvesWeb.Models;
using Dloc.Data.Context;
using Dloc.Domain.Entities;
using Dloc.Domain.IRepositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace Dloc.ControleAvesWeb.Controllers
{
    public class AveController : Controller
    {
        private readonly IAveRepository _aveRepository;

        public AveController(IAveRepository aveRepository) => _aveRepository = aveRepository;

        public ActionResult Index() => View(new MainAveModel { Aves = _aveRepository.GetAll() });

        public ActionResult Details(int id) =>         
            View(new MainAveModel { Ave = new Ave { id = id } });
        
        public ActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Ave model)
        {
            try
            {
                model.codigo = _aveRepository.GetCodigo();
                model.Ativar(model);
                _aveRepository.Register(model);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception e)
            {
                return View();
            }
        }

        public ActionResult Edit(int id) => View(_aveRepository.GetById(id));

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Ave model)
        {
            try
            {
                model.Ativar(model);
                _aveRepository.Update(model);
                model.Ativar(model);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AveController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AveController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
