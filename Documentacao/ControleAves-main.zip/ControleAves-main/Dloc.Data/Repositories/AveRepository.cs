﻿using Dloc.Data.Context;
using Dloc.Domain.DTOs;
using Dloc.Domain.Entities;
using Dloc.Domain.Enumeration;
using Dloc.Domain.IRepositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Dloc.Data.Repositories
{
    public class AveRepository : IAveRepository
    {
        private readonly DataContext context;

        public AveRepository(DataContext context) =>
            this.context = context;

        public void Register(Ave ave)
        {
            context.Entry(ave).State = EntityState.Added;
            context.SaveChanges();
        }

        public void Update(Ave ave)
        {
            context.Entry(ave).State = EntityState.Modified;
            context.SaveChanges();
        }

        public Ave GetById(int id)
        {
            return context.Ave.Find(id);
        }

        public string GetCodigo()
        {
            var contador = context.Ave.Count() + 1;
            return new Ave().Sequencial(contador);
        }

        public List<Ave> GetAll()
        {
            var aves = context.Ave.Where(x => x.ativo);
            var _aves = new List<Ave>();

            foreach (var item in aves)
            {
                _aves.Add(new Ave
                {
                    id = item.id,
                    nome = item.nome,   // item.codigo + item.nome == null ? "" : "-" + item.nome,
                    codigo = item.codigo,
                    sexo = item.sexo,
                    cor = item.cor,
                    dt_nascimento = item.dt_nascimento,
                    ativo = item.ativo
                });
            }

            return _aves;
        }

        public Pai GetPai(int id)
        {
            return context.Pai.Include(x => x.id_paiNavigation).Where(x => x.id_ave == id).FirstOrDefault();
        }

        public Mae GetMae(int id)
        {
            return context.Mae.Include(x => x.id_maeNavigation).Where(x => x.id_ave == id).FirstOrDefault();
        }

        public Filho GetFilho(int id)
        {
            return context.Filho.Where(x => x.id_filho == id).FirstOrDefault();
        }

        public List<Filho> GetFilhos(int id)
        {
            return context.Filho.Include(x => x.id_filhoNavigation).Where(x => x.id_pai == id || x.id_mae == id).ToList();
        }

        public List<Filho> GetNetos(List<Filho> filhos)
        {
            var _netos = new List<Filho>();

            foreach (var item in filhos)
            {
                var lista = context.Filho.Include(x => x.id_filhoNavigation).Where(x => x.id_pai == item.id_filho || x.id_mae == item.id_filho).ToList();

                foreach (var neto in lista)
                {
                    _netos.Add(neto);
                }
            }

            return _netos;
        }

        public List<Filho> GetBisnetos(List<Filho> netos)
        {
            var _bisnetos = new List<Filho>();

            foreach (var neto in netos)
            {
                var lista = context.Filho.Include(x => x.id_filhoNavigation).Where(x => x.id_pai == neto.id_filho).ToList();

                foreach (var bisneto in lista)
                {
                    _bisnetos.Add(bisneto);
                }
            }

            return _bisnetos;
        }

        public List<FilhoDTO> GetTrinetos(List<Filho> bisnetos)
        {
            var _trinetos = new List<FilhoDTO>();

            foreach (var bisneto in bisnetos)
            {
                var lista = context.Filho.Include(x => x.id_filhoNavigation).Where(x => x.id_pai == bisneto.id_filho).ToList();

                foreach (var trineto in lista)
                {
                    _trinetos.Add(new FilhoDTO
                    {
                        id_filho = trineto.id_filhoNavigation.id,
                        id_pai = trineto.id_pai,
                        id_mae = trineto.id_mae,
                        nm_filho = trineto.id_filhoNavigation.nome
                    });
                }
            }

            return _trinetos;
        }

        public List<Casamento> GetCasamentos(int id)
        {
            return context.Casamento.Include(x => x.id_machoNavigation).Include(x => x.id_femeaNavigation).Where(x => x.id_machoNavigation.id == id || x.id_femeaNavigation.id == id).ToList();
        }

        public void ExcluirFilho(int id)
        {
            var filho = context.Filho.Where(x => x.id_filho == id);
            context.Remove(filho.First());
            context.SaveChanges();
        }

        public void ExcluirPortador(int id)
        {
            var portador = context.PortadorAve.Where(x => x.id == id);
            context.Remove(portador.First());
            context.SaveChanges();
        }

        public void ExcluirMutacao(int id)
        {
            var mutacao = context.MutacaoAve.Where(x => x.id == id);
            context.Remove(mutacao.First());
            context.SaveChanges();
        }

        public bool Existe(int id, int parente)
        {
            switch (parente)
            {
                case (int)ParenteEnun.Pai:
                    return context.Pai.Where(x => x.id_ave == id).Any();

                case (int)ParenteEnun.Mae:
                    return context.Mae.Where(x => x.id_ave == id).Any();

                case (int)ParenteEnun.Filho:
                    return context.Filho.Where(x => x.id_filho == id).Any();

                default:
                    return false;
            }
        }

        public IDictionary<int, string> GetDropMutacoes()
        {
            return context.Mutacao.ToDictionary(x => x.id, x => x.ds_mutacao);
        }

        public IDictionary<int, string> GetDropPortadores()
        {
            return context.Portador.ToDictionary(x => x.id, x => x.ds_portador);
        }

        public IDictionary<int, string> GetDropAves(int sexo)
        {
            if (sexo.Equals((int)SexoEnun.Ambos))
            {
                return context.Ave.ToDictionary(x => x.id, x => String.IsNullOrEmpty(x.nome) ? x.codigo : x.codigo + "-" + x.nome);
            }
            else
            {
                return context.Ave.Where(x => x.sexo == sexo).ToDictionary(x => x.id, x => String.IsNullOrEmpty(x.nome) ? x.codigo : x.codigo + "-" + x.nome);
            }
        }

        public IDictionary<int, string> GetDropFilhos()
        {
            var aves = new List<Ave>();

            var _aves = context.Ave.Include(x => x.GetFilhos);

            foreach (var ave in context.Ave.AsNoTracking().ToList())
            {
                if (!context.Filho.AsNoTracking().Where(x => x.id_filho == ave.id).Any())
                {
                    aves.Add(ave);
                }
            }

            return aves.ToDictionary(x => x.id, x => String.IsNullOrEmpty(x.nome) ? x.codigo : x.codigo + "-" + x.nome);
        }
    }
}
